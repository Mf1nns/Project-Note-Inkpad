package com.inkpad.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(primary = Color(0xFF3B5BDB), background = Color(0xFFF7F7F9), surface = Color.White)
private val Dark = darkColorScheme(primary = Color(0xFF748FFC), background = Color(0xFF121214), surface = Color(0xFF1C1C1F))

@Composable
fun InkPadTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
