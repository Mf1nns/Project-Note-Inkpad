# InkPad
Open this folder in Android Studio (Ladybug or newer, JDK 17). Let it sync; it generates the Gradle wrapper jar.
Modules: app (UI), core:model (pure Kotlin), core:ink (input + tools), core:data (Room).
