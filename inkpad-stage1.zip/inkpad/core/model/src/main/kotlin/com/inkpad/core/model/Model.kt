package com.inkpad.core.model

/** Pure-Kotlin domain model: no Android dependencies, shared by every module. */
enum class PaperTemplate { BLANK, RULED, GRID, DOTTED, CORNELL, MUSIC, CUSTOM }

enum class PageSize(val widthPt: Float, val heightPt: Float) {
    A4(595f, 842f), A5(420f, 595f), LETTER(612f, 792f), TABLET(800f, 1280f)
}

enum class ToolType { PEN, BALLPOINT, FOUNTAIN, PENCIL, HIGHLIGHTER, ERASER, LASSO, SHAPE, TEXT, IMAGE, LASER }

data class Notebook(
    val id: Long = 0,
    val title: String,
    val folderId: Long? = null,
    val coverColor: Long = 0xFF3B5BDB,
    val template: PaperTemplate = PaperTemplate.RULED,
    val pageSize: PageSize = PageSize.A4,
    val paperColor: Long = 0xFFFFFFFF,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = createdAt,
)

data class Folder(val id: Long = 0, val name: String, val parentId: Long? = null)

/** One sampled input point. Page coordinates, pressure 0..1, tilt in radians, time in ms. */
data class InkPoint(val x: Float, val y: Float, val pressure: Float, val tilt: Float, val t: Long)

data class InkStroke(
    val id: Long = 0,
    val tool: ToolType,
    val color: Long,
    val width: Float,
    val points: List<InkPoint>,
)
