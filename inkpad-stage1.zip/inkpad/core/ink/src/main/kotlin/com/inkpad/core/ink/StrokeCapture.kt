package com.inkpad.core.ink

import android.view.MotionEvent
import com.inkpad.core.model.InkPoint

/** What produced a pointer. Lets the editor treat stylus and finger independently (palm rejection). */
enum class Source { STYLUS, FINGER, ERASER_TIP, OTHER }

fun MotionEvent.sourceAt(i: Int): Source = when (getToolType(i)) {
    MotionEvent.TOOL_TYPE_STYLUS -> Source.STYLUS
    MotionEvent.TOOL_TYPE_ERASER -> Source.ERASER_TIP
    MotionEvent.TOOL_TYPE_FINGER -> Source.FINGER
    else -> Source.OTHER
}

/**
 * Extracts every sample of pointer [i], including historical (batched) samples.
 * Skipping history is the #1 cause of jagged, polygonal strokes on fast writing.
 */
fun MotionEvent.samples(i: Int, out: MutableList<InkPoint> = ArrayList(historySize + 1)): MutableList<InkPoint> {
    for (h in 0 until historySize) {
        out += InkPoint(
            getHistoricalX(i, h), getHistoricalY(i, h),
            getHistoricalPressure(i, h).coerceIn(0f, 1f),
            getHistoricalAxisValue(MotionEvent.AXIS_TILT, i, h),
            getHistoricalEventTime(h),
        )
    }
    out += InkPoint(getX(i), getY(i), getPressure(i).coerceIn(0f, 1f), getAxisValue(MotionEvent.AXIS_TILT, i), eventTime)
    return out
}
