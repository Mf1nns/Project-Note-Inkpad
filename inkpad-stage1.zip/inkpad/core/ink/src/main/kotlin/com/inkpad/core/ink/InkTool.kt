package com.inkpad.core.ink

import com.inkpad.core.model.InkPoint
import com.inkpad.core.model.ToolType

/** Plug-in contract for tools. New tools = new implementation + registry entry; the editor never changes. */
interface InkTool {
    val type: ToolType
    fun onDown(p: InkPoint)
    fun onMove(points: List<InkPoint>)
    fun onUp()
    fun onCancel()
}

object ToolRegistry {
    private val tools = mutableMapOf<ToolType, InkTool>()
    fun register(tool: InkTool) { tools[tool.type] = tool }
    operator fun get(type: ToolType): InkTool? = tools[type]
}
