package com.inkpad.core.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "notebooks")
data class NotebookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val folderId: Long?,
    val coverColor: Long,
    val template: String,
    val pageSize: String,
    val paperColor: Long,
    val createdAt: Long,
    val updatedAt: Long,
)

@Dao
interface NotebookDao {
    @Query("SELECT * FROM notebooks ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<NotebookEntity>>
    @Insert suspend fun insert(n: NotebookEntity): Long
    @Update suspend fun update(n: NotebookEntity)
    @Delete suspend fun delete(n: NotebookEntity)
}

@Database(entities = [NotebookEntity::class], version = 1, exportSchema = false)
abstract class InkDatabase : RoomDatabase() {
    abstract fun notebooks(): NotebookDao

    companion object {
        @Volatile private var inst: InkDatabase? = null
        fun get(ctx: Context): InkDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, InkDatabase::class.java, "inkpad.db")
                .build().also { inst = it }
        }
    }
}
